from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from agents.orchestrator import Orchestrator
from governance.sql_guard import SQLGuard
from gateway.audit import AuditLogger
from gateway.rate_limit import RateLimiter

app = FastAPI(title="Dagger Leader AI", version="2.0.0", description="Governed AI data agent")
orchestrator = Orchestrator()
guard = SQLGuard()
audit = AuditLogger()
limiter = RateLimiter()

class QueryRequest(BaseModel):
    question: str = Field(min_length=2)
    connector: str = "mock"
    execute: bool = False
    max_rows: int = Field(default=100, ge=1, le=10000)

@app.get("/")
def root(): return {"name":"Dagger Leader AI","version":"2.0.0","status":"ok"}

@app.get("/health")
def health(): return {"status":"healthy","components":{"api":"up","governance":"up","agents":"up"}}

@app.post("/query")
def query(req: QueryRequest, x_api_key: str | None = Header(default=None)):
    if not limiter.allow(x_api_key or "anonymous"):
        raise HTTPException(429, "Rate limit exceeded")
    result = orchestrator.run(req.question, req.connector, req.execute, req.max_rows)
    audit.write({"question":req.question,"connector":req.connector,"status":result.get("status")})
    return result

@app.post("/governance/check")
def governance_check(sql: str, max_rows: int = 100):
    return guard.inspect(sql, max_rows=max_rows)
