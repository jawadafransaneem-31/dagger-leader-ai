from fastapi.testclient import TestClient
from gateway.api import app
client=TestClient(app)
def test_health(): assert client.get('/health').status_code==200
def test_query(): assert client.post('/query',json={'question':'how many users?'}).json()['status']=='ok'
