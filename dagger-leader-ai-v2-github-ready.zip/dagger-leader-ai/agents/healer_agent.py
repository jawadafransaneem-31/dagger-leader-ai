class HealerAgent:
    def recover(self,error,sql): return {"error":str(error),"sql":sql,"healed":False}
