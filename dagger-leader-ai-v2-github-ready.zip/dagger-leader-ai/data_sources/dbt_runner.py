"""
data_sources/dbt_runner.py

Thin wrapper around the dbt CLI so the Schema Agent can pull model
definitions/descriptions from a dbt project (manifest.json / models/*.yml),
and so the Healer Agent can trigger `dbt run` / `dbt test` when a query
depends on a stale or missing model.
"""
import json
import logging
import subprocess
from pathlib import Path
from typing import List, Dict, Any

from config.settings import settings

logger = logging.getLogger("dagger_leader.dbt")


class DbtRunner:
    def __init__(self):
        self.project_dir = Path(settings.dbt.project_dir)
        self.profiles_dir = Path(settings.dbt.profiles_dir)

    def _run(self, args: List[str]) -> subprocess.CompletedProcess:
        cmd = ["dbt", *args, "--project-dir", str(self.project_dir), "--profiles-dir", str(self.profiles_dir)]
        logger.info("Running: %s", " ".join(cmd))
        return subprocess.run(cmd, capture_output=True, text=True, timeout=600)

    def run_models(self, select: str = None) -> Dict[str, Any]:
        args = ["run"]
        if select:
            args += ["--select", select]
        proc = self._run(args)
        return {"success": proc.returncode == 0, "stdout": proc.stdout, "stderr": proc.stderr}

    def test_models(self, select: str = None) -> Dict[str, Any]:
        args = ["test"]
        if select:
            args += ["--select", select]
        proc = self._run(args)
        return {"success": proc.returncode == 0, "stdout": proc.stdout, "stderr": proc.stderr}

    def list_models_from_manifest(self) -> List[Dict[str, Any]]:
        """Read compiled manifest.json (after `dbt compile`/`dbt run`) for
        model -> column -> description metadata, in the same shape the
        Schema Agent expects."""
        manifest_path = self.project_dir / "target" / "manifest.json"
        if not manifest_path.exists():
            logger.warning("No manifest.json found at %s — run `dbt compile` first.", manifest_path)
            return []

        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)

        tables = []
        for node_id, node in manifest.get("nodes", {}).items():
            if node.get("resource_type") != "model":
                continue
            columns = [
                {"name": col_name, "type": col.get("data_type", "unknown")}
                for col_name, col in node.get("columns", {}).items()
            ]
            tables.append({
                "name": node.get("name"),
                "description": node.get("description", ""),
                "columns": columns,
            })
        return tables
