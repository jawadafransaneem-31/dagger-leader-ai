"""
agents/memory_agent.py

Retrieves similar past question/SQL pairs from ChromaDB so the SQL Agent
can reuse proven patterns (join paths, date logic, business-term handling).
"""
import logging
from core.state import AgentState
from vector_db.chroma_client import chroma_client

logger = logging.getLogger("dagger_leader.memory_agent")


def run(state: AgentState) -> AgentState:
    examples = chroma_client.search_query_memory(state["question"], top_k=3)
    state["memory_examples"] = examples
    state.setdefault("agents_used", []).append("memory_agent")
    logger.info("Memory Agent retrieved %d similar past quer(y/ies).", len(examples))
    return state


def remember(question: str, sql: str, success: bool) -> None:
    """Call after a query completes so future questions benefit from it."""
    chroma_client.store_query_memory(question, sql, success)
