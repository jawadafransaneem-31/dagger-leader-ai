"""
Central configuration for Dagger Leader.
All values are loaded from environment variables (see .env.example).
"""
import os
from dataclasses import dataclass, field
from dotenv import load_dotenv

load_dotenv()


def _env(key: str, default: str = "") -> str:
    return os.getenv(key, default)


def _env_int(key: str, default: int) -> int:
    try:
        return int(os.getenv(key, default))
    except (TypeError, ValueError):
        return default


@dataclass
class LLMSettings:
    provider: str = field(default_factory=lambda: _env("LLM_PROVIDER", "anthropic"))
    anthropic_api_key: str = field(default_factory=lambda: _env("ANTHROPIC_API_KEY"))
    anthropic_model: str = field(default_factory=lambda: _env("ANTHROPIC_MODEL", "claude-sonnet-4-6"))
    openai_api_key: str = field(default_factory=lambda: _env("OPENAI_API_KEY"))
    openai_model: str = field(default_factory=lambda: _env("OPENAI_MODEL", "gpt-4o"))
    max_tokens: int = field(default_factory=lambda: _env_int("LLM_MAX_TOKENS", 1024))
    temperature: float = field(default_factory=lambda: float(_env("LLM_TEMPERATURE", "0.0")))


@dataclass
class SnowflakeSettings:
    account: str = field(default_factory=lambda: _env("SNOWFLAKE_ACCOUNT"))
    user: str = field(default_factory=lambda: _env("SNOWFLAKE_USER"))
    password: str = field(default_factory=lambda: _env("SNOWFLAKE_PASSWORD"))
    warehouse: str = field(default_factory=lambda: _env("SNOWFLAKE_WAREHOUSE"))
    database: str = field(default_factory=lambda: _env("SNOWFLAKE_DATABASE"))
    schema: str = field(default_factory=lambda: _env("SNOWFLAKE_SCHEMA", "PUBLIC"))
    role: str = field(default_factory=lambda: _env("SNOWFLAKE_ROLE"))


@dataclass
class BigQuerySettings:
    project_id: str = field(default_factory=lambda: _env("BQ_PROJECT_ID"))
    dataset: str = field(default_factory=lambda: _env("BQ_DATASET"))
    credentials_path: str = field(default_factory=lambda: _env("GOOGLE_APPLICATION_CREDENTIALS"))


@dataclass
class ChromaSettings:
    persist_dir: str = field(default_factory=lambda: _env("CHROMA_PERSIST_DIR", "./chroma_db"))
    collection_name: str = field(default_factory=lambda: _env("CHROMA_COLLECTION_NAME", "schemas"))
    memory_collection_name: str = field(default_factory=lambda: _env("CHROMA_MEMORY_COLLECTION", "query_memory"))


@dataclass
class Neo4jSettings:
    uri: str = field(default_factory=lambda: _env("NEO4J_URI", "bolt://localhost:7687"))
    user: str = field(default_factory=lambda: _env("NEO4J_USER", "neo4j"))
    password: str = field(default_factory=lambda: _env("NEO4J_PASSWORD", "password"))


@dataclass
class KafkaSettings:
    bootstrap_servers: str = field(default_factory=lambda: _env("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"))
    topic: str = field(default_factory=lambda: _env("KAFKA_TOPIC", "realtime_data"))
    group_id: str = field(default_factory=lambda: _env("KAFKA_GROUP_ID", "dagger-leader"))


@dataclass
class DbtSettings:
    project_dir: str = field(default_factory=lambda: _env("DBT_PROJECT_DIR", "./dbt_project"))
    profiles_dir: str = field(default_factory=lambda: _env("DBT_PROFILES_DIR", "./dbt_project"))


@dataclass
class GovernanceSettings:
    max_rows: int = field(default_factory=lambda: _env_int("MAX_ROWS_LIMIT", 1000))
    query_timeout_seconds: int = field(default_factory=lambda: _env_int("QUERY_TIMEOUT_SECONDS", 30))
    max_heal_retries: int = field(default_factory=lambda: _env_int("MAX_HEAL_RETRIES", 3))
    audit_log_path: str = field(default_factory=lambda: _env("AUDIT_LOG_PATH", "./audit.log"))


@dataclass
class AppSettings:
    host: str = field(default_factory=lambda: _env("APP_HOST", "0.0.0.0"))
    port: int = field(default_factory=lambda: _env_int("APP_PORT", 8080))
    log_level: str = field(default_factory=lambda: _env("LOG_LEVEL", "INFO"))
    active_data_source: str = field(default_factory=lambda: _env("ACTIVE_DATA_SOURCE", "mock"))


@dataclass
class Settings:
    llm: LLMSettings = field(default_factory=LLMSettings)
    snowflake: SnowflakeSettings = field(default_factory=SnowflakeSettings)
    bigquery: BigQuerySettings = field(default_factory=BigQuerySettings)
    chroma: ChromaSettings = field(default_factory=ChromaSettings)
    neo4j: Neo4jSettings = field(default_factory=Neo4jSettings)
    kafka: KafkaSettings = field(default_factory=KafkaSettings)
    dbt: DbtSettings = field(default_factory=DbtSettings)
    governance: GovernanceSettings = field(default_factory=GovernanceSettings)
    app: AppSettings = field(default_factory=AppSettings)


settings = Settings()
