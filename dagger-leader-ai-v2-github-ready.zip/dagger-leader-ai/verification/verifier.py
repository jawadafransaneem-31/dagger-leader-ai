import re
class VerificationSuite:
    def run(self,question,sql,result=None):
        checks={"is_select":bool(re.match(r"^\s*SELECT\b",sql,re.I)),"has_limit":bool(re.search(r"\bLIMIT\s+\d+\b",sql,re.I)),"no_mutation":not bool(re.search(r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE)\b",sql,re.I)),"execution_available":result is not None}
        return {"passed":all(v for k,v in checks.items() if k!="execution_available"),"checks":checks}
