import subprocess
class DbtRunner:
    def run(self, args):
        cmd=["dbt",*args]
        return subprocess.run(cmd,capture_output=True,text=True,timeout=300)
