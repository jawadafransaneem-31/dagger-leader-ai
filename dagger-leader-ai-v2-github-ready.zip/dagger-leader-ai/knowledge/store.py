import json, os
class KnowledgeStore:
    def __init__(self,path="data/knowledge.json"): self.path=path; os.makedirs(os.path.dirname(path),exist_ok=True)
    def put(self,key,value):
        data=self.get_all(); data[key]=value
        with open(self.path,"w",encoding="utf-8") as f: json.dump(data,f,indent=2)
    def get_all(self):
        if not os.path.exists(self.path): return {}
        with open(self.path,encoding="utf-8") as f: return json.load(f)
