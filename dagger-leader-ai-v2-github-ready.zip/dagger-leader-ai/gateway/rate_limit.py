import time
from collections import defaultdict, deque
class RateLimiter:
    def __init__(self, limit=60, window=60): self.limit=limit; self.window=window; self.events=defaultdict(deque)
    def allow(self,key):
        now=time.time(); q=self.events[key]
        while q and q[0] <= now-self.window: q.popleft()
        if len(q)>=self.limit: return False
        q.append(now); return True
