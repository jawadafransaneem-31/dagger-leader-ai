"""
knowledge_graph/neo4j_client.py

Semantic layer: maps business terms ("revenue", "Q1 2025", "active customer")
to concrete database columns/expressions via a Neo4j knowledge graph.

Falls back to a small built-in dictionary when Neo4j is unavailable, so the
Semantic Agent still works out of the box.
"""
import logging
from typing import Optional, Dict

from config.settings import settings

logger = logging.getLogger("dagger_leader.neo4j")

_FALLBACK_TERMS: Dict[str, str] = {
    "revenue": "orders.order_value",
    "customer": "customers.customer_name",
    "active customer": "customers.status = 'active'",
    "region": "customers.region",
    "order date": "orders.order_date",
    "profit": "orders.order_value - orders.cost",
}


class Neo4jClient:
    def __init__(self):
        self._driver = None
        self._connect()

    def _connect(self) -> None:
        try:
            from neo4j import GraphDatabase
            self._driver = GraphDatabase.driver(
                settings.neo4j.uri,
                auth=(settings.neo4j.user, settings.neo4j.password),
            )
            self._driver.verify_connectivity()
            logger.info("Connected to Neo4j at %s", settings.neo4j.uri)
        except Exception as e:
            logger.warning("Neo4j unavailable (%s) — using in-memory fallback term map.", e)
            self._driver = None

    @property
    def available(self) -> bool:
        return self._driver is not None

    def resolve_term(self, term: str) -> Optional[str]:
        """Return the DB column/expression a business term maps to."""
        term_norm = term.strip().lower()

        if self.available:
            query = """
            MATCH (t:BusinessTerm {name: $name})-[:MAPS_TO]->(c:Column)
            RETURN c.table + '.' + c.name AS mapping
            LIMIT 1
            """
            try:
                with self._driver.session() as session:
                    record = session.run(query, name=term_norm).single()
                    if record:
                        return record["mapping"]
            except Exception as e:
                logger.warning("Neo4j query failed, falling back: %s", e)

        return _FALLBACK_TERMS.get(term_norm)

    def upsert_term(self, term: str, table: str, column: str) -> None:
        if not self.available:
            _FALLBACK_TERMS[term.lower()] = f"{table}.{column}"
            return
        query = """
        MERGE (t:BusinessTerm {name: $term})
        MERGE (c:Column {table: $table, name: $column})
        MERGE (t)-[:MAPS_TO]->(c)
        """
        with self._driver.session() as session:
            session.run(query, term=term.lower(), table=table, column=column)

    def close(self) -> None:
        if self._driver:
            self._driver.close()


neo4j_client = Neo4jClient()
