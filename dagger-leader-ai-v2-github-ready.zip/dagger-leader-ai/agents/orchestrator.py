from agents.schema_agent import SchemaAgent
from agents.semantic_agent import SemanticAgent
from agents.sql_agent import SQLAgent
from agents.validator import Validator
from agents.healer_agent import HealerAgent
from agents.explainer_agent import ExplainerAgent
from connectors.registry import get
from governance.sql_guard import SQLGuard
from verification.verifier import VerificationSuite
class Orchestrator:
    def __init__(self): self.schema=SchemaAgent(); self.semantic=SemanticAgent(); self.sql=SQLAgent(); self.validator=Validator(); self.healer=HealerAgent(); self.explainer=ExplainerAgent(); self.guard=SQLGuard(); self.verifier=VerificationSuite()
    def run(self, question, connector="mock", execute=False, max_rows=100):
        c=get(connector); schema=self.schema.inspect(c); intent=self.semantic.analyze(question,schema); sql=self.sql.generate(question,schema,intent)
        checked=self.guard.inspect(sql,max_rows)
        if not checked["allowed"]: return {"status":"blocked","question":question,"sql":sql,"governance":checked}
        result=None
        if execute:
            try: result=c.execute(checked["sql"],max_rows)
            except Exception as e: result=self.healer.recover(e,checked["sql"])
        verification=self.verifier.run(question,checked["sql"],result)
        return {"status":"ok","plan":["plan","scan","govern","build","report"],"question":question,"intent":intent,"sql":checked["sql"],"governance":checked,"result":result.__dict__ if hasattr(result,'__dict__') else result,"verification":verification,"explanation":self.explainer.explain(question,checked["sql"],result)}
