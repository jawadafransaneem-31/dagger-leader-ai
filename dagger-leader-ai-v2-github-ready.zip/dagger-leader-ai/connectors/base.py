from dataclasses import dataclass, field
from typing import Any
@dataclass
class QueryResult:
    columns:list[str]=field(default_factory=list); rows:list[dict[str,Any]]=field(default_factory=list); sql:str=""; elapsed_ms:float=0; error:str|None=None
class Connector:
    name="base"
    def __init__(self, **kwargs): self.config=kwargs
    def schema(self): return []
    def execute(self, sql, max_rows=100): raise NotImplementedError
