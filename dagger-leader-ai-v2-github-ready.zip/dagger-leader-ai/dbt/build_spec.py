from dataclasses import dataclass,field
@dataclass
class BuildSpec:
    model_name:str
    description:str
    depends_on:list[str]=field(default_factory=list)
    tests:list[str]=field(default_factory=list)
