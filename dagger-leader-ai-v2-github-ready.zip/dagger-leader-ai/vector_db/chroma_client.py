"""
vector_db/chroma_client.py

Wraps ChromaDB for two purposes:
  1. Schema embeddings  -> table/column discovery ("Schema Agent")
  2. Query memory       -> past question/SQL pairs for retrieval ("Memory Agent")

Uses an in-process, locally-persisted ChromaDB instance (no server required).
"""
import logging
import uuid
from typing import List, Dict, Any, Optional

from config.settings import settings

logger = logging.getLogger("dagger_leader.chroma")


class ChromaClient:
    def __init__(self):
        self._client = None
        self._schema_collection = None
        self._memory_collection = None
        self._init_client()

    def _init_client(self) -> None:
        try:
            import chromadb
            self._client = chromadb.PersistentClient(path=settings.chroma.persist_dir)
            self._schema_collection = self._client.get_or_create_collection(
                settings.chroma.collection_name
            )
            self._memory_collection = self._client.get_or_create_collection(
                settings.chroma.memory_collection_name
            )
            logger.info("ChromaDB initialized at %s", settings.chroma.persist_dir)
        except ImportError:
            logger.warning("chromadb not installed — schema/memory search runs in no-op mode.")

    @property
    def available(self) -> bool:
        return self._client is not None

    # ---- Schema embeddings -------------------------------------------------

    def index_schema(self, tables: List[Dict[str, Any]]) -> None:
        """tables: [{"name": "orders", "description": "...", "columns": [...]}]"""
        if not self.available:
            return
        ids, docs, metas = [], [], []
        for t in tables:
            cols = ", ".join(c.get("name", "") for c in t.get("columns", []))
            doc = f"Table {t['name']}: {t.get('description', '')}. Columns: {cols}"
            ids.append(t["name"])
            docs.append(doc)
            metas.append({"table": t["name"], "columns": cols})
        self._schema_collection.upsert(ids=ids, documents=docs, metadatas=metas)

    def search_schema(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        if not self.available:
            return []
        results = self._schema_collection.query(query_texts=[query], n_results=top_k)
        out = []
        for doc, meta, dist in zip(
            results.get("documents", [[]])[0],
            results.get("metadatas", [[]])[0],
            results.get("distances", [[]])[0],
        ):
            out.append({"document": doc, "metadata": meta, "similarity": 1 - dist})
        return out

    # ---- Query memory -------------------------------------------------------

    def store_query_memory(self, question: str, sql: str, success: bool) -> None:
        if not self.available:
            return
        self._memory_collection.add(
            ids=[str(uuid.uuid4())],
            documents=[question],
            metadatas=[{"sql": sql, "success": success}],
        )

    def search_query_memory(self, question: str, top_k: int = 3) -> List[Dict[str, Any]]:
        if not self.available:
            return []
        try:
            results = self._memory_collection.query(query_texts=[question], n_results=top_k)
        except Exception as e:
            logger.warning("Memory search failed (empty collection?): %s", e)
            return []
        out = []
        for doc, meta, dist in zip(
            results.get("documents", [[]])[0],
            results.get("metadatas", [[]])[0],
            results.get("distances", [[]])[0],
        ):
            out.append({"question": doc, "sql": meta.get("sql"), "similarity": 1 - dist})
        return out


chroma_client = ChromaClient()
