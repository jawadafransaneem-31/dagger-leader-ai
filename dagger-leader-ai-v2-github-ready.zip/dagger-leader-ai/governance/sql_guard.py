import re
from dataclasses import dataclass, field
@dataclass
class GuardResult:
    passed: bool
    sql: str
    reasons: list[str]=field(default_factory=list)
    warnings: list[str]=field(default_factory=list)
    fan_out_risk: bool=False
    risk: str="low"
class SQLGuard:
    BLOCKED=re.compile(r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|CREATE|MERGE|GRANT|REVOKE)\b",re.I)
    DANGEROUS=re.compile(r"\b(pg_read_file|pg_ls_dir|load_file|xp_cmdshell|copy\s+.*program)\b",re.I)
    def __init__(self,max_rows=100): self.max_rows=max_rows
    def validate(self,sql):
        sql=(sql or '').strip()
        if not sql: return GuardResult(False,"",["Forbidden: empty SQL"],risk="high")
        reasons=[]; warnings=[]
        if self.BLOCKED.search(sql): reasons.append("Forbidden: DDL/DML statement")
        if self.DANGEROUS.search(sql): reasons.append("Forbidden: dangerous function")
        if not re.match(r"^\s*SELECT\b",sql,re.I): reasons.append("Forbidden: only SELECT statements are allowed")
        fan_out=bool(re.search(r"\bJOIN\b",sql,re.I))
        if fan_out: warnings.append("Potential fan-out risk: JOIN query should be checked for one-to-many multiplication.")
        rewritten=sql
        if not reasons and not re.search(r"\bLIMIT\s+\d+\b",sql,re.I): rewritten=sql.rstrip(';')+f" LIMIT {self.max_rows};"
        return GuardResult(not reasons,rewritten,reasons,warnings,fan_out,"high" if reasons else ("medium" if fan_out else "low"))
    def inspect(self,sql,max_rows=None):
        old=self.max_rows
        if max_rows is not None: self.max_rows=max_rows
        r=self.validate(sql); self.max_rows=old
        return {"allowed":r.passed,"sql":r.sql,"reasons":r.reasons,"warnings":r.warnings,"fan_out_risk":r.fan_out_risk,"risk":r.risk}
    def enforce(self,sql,max_rows=None):
        r=self.inspect(sql,max_rows)
        if not r["allowed"]: raise PermissionError('; '.join(r["reasons"]))
        return r["sql"]
