"""
core/llm_client.py

Thin wrapper around Anthropic / OpenAI so agents don't care which
provider is configured. Falls back to a deterministic offline stub
when no API key is set, so the whole pipeline is runnable / testable
without network access or credentials.
"""
import logging
from config.settings import settings

logger = logging.getLogger("dagger_leader.llm")


class LLMClient:
    def __init__(self):
        self.provider = settings.llm.provider
        self._anthropic = None
        self._openai = None

        if self.provider == "anthropic" and settings.llm.anthropic_api_key:
            try:
                import anthropic
                self._anthropic = anthropic.Anthropic(api_key=settings.llm.anthropic_api_key)
            except ImportError:
                logger.warning("anthropic package not installed; falling back to stub LLM.")
        elif self.provider == "openai" and settings.llm.openai_api_key:
            try:
                import openai
                self._openai = openai.OpenAI(api_key=settings.llm.openai_api_key)
            except ImportError:
                logger.warning("openai package not installed; falling back to stub LLM.")

    @property
    def is_live(self) -> bool:
        return self._anthropic is not None or self._openai is not None

    def complete(self, system: str, prompt: str, max_tokens: int = None) -> str:
        """Return a plain-text completion. Falls back to a stub if no provider configured."""
        max_tokens = max_tokens or settings.llm.max_tokens

        if self._anthropic:
            resp = self._anthropic.messages.create(
                model=settings.llm.anthropic_model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": prompt}],
            )
            return "".join(block.text for block in resp.content if block.type == "text")

        if self._openai:
            resp = self._openai.chat.completions.create(
                model=settings.llm.openai_model,
                max_tokens=max_tokens,
                temperature=settings.llm.temperature,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ],
            )
            return resp.choices[0].message.content

        logger.debug("No LLM provider configured — using offline stub response.")
        return self._stub(system, prompt)

    @staticmethod
    def _stub(system: str, prompt: str) -> str:
        """Deterministic offline fallback so the pipeline never hard-crashes
        without an API key. Real answers require a configured LLM key."""
        return (
            "[offline-stub] No ANTHROPIC_API_KEY / OPENAI_API_KEY configured. "
            "Set one in .env to get real model output for prompt: "
            f"{prompt[:120]}..."
        )


llm_client = LLMClient()
