"""
data_sources/snowflake_connector.py

Real Snowflake connector. Requires `snowflake-connector-python` and valid
credentials in .env (SNOWFLAKE_ACCOUNT / USER / PASSWORD / WAREHOUSE / DATABASE).
"""
import logging
import time
from typing import List, Dict, Any

from config.settings import settings
from core.data_connector import BaseConnector, QueryResult

logger = logging.getLogger("dagger_leader.snowflake")


class SnowflakeConnector(BaseConnector):
    name = "snowflake"

    def __init__(self):
        self._conn = None
        self._connect()

    def _connect(self):
        try:
            import snowflake.connector
        except ImportError as e:
            raise RuntimeError(
                "snowflake-connector-python is not installed. "
                "Run: pip install snowflake-connector-python"
            ) from e

        cfg = settings.snowflake
        missing = [k for k, v in {
            "SNOWFLAKE_ACCOUNT": cfg.account,
            "SNOWFLAKE_USER": cfg.user,
            "SNOWFLAKE_PASSWORD": cfg.password,
            "SNOWFLAKE_WAREHOUSE": cfg.warehouse,
            "SNOWFLAKE_DATABASE": cfg.database,
        }.items() if not v]
        if missing:
            raise RuntimeError(f"Missing Snowflake env vars: {missing}")

        self._conn = snowflake.connector.connect(
            account=cfg.account,
            user=cfg.user,
            password=cfg.password,
            warehouse=cfg.warehouse,
            database=cfg.database,
            schema=cfg.schema,
            role=cfg.role or None,
        )
        logger.info("Connected to Snowflake account=%s database=%s", cfg.account, cfg.database)

    def execute(self, sql: str) -> QueryResult:
        start = time.perf_counter()
        cur = self._conn.cursor()
        try:
            cur.execute(sql, timeout=settings.governance.query_timeout_seconds)
            columns = [c[0] for c in cur.description] if cur.description else []
            rows = cur.fetchall()
            duration_ms = (time.perf_counter() - start) * 1000
            return QueryResult(
                columns=columns,
                rows=[list(r) for r in rows],
                row_count=len(rows),
                duration_ms=duration_ms,
            )
        except Exception as e:
            duration_ms = (time.perf_counter() - start) * 1000
            logger.error("Snowflake query failed: %s", e)
            return QueryResult(columns=[], rows=[], row_count=0, duration_ms=duration_ms, error=str(e))
        finally:
            cur.close()

    def list_tables(self) -> List[Dict[str, Any]]:
        cur = self._conn.cursor()
        try:
            cur.execute(
                f"SELECT TABLE_NAME, COMMENT FROM {settings.snowflake.database}."
                f"INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = %s",
                (settings.snowflake.schema,),
            )
            tables = []
            for table_name, comment in cur.fetchall():
                col_cur = self._conn.cursor()
                col_cur.execute(
                    f"SELECT COLUMN_NAME, DATA_TYPE FROM {settings.snowflake.database}."
                    f"INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = %s",
                    (table_name,),
                )
                columns = [{"name": c[0], "type": c[1]} for c in col_cur.fetchall()]
                col_cur.close()
                tables.append({"name": table_name, "description": comment or "", "columns": columns})
            return tables
        finally:
            cur.close()
