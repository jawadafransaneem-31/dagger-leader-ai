"""
core/sql_generator.py

Builds the few-shot prompt used by the SQL Agent and extracts a clean SQL
statement out of the LLM's (possibly markdown-fenced) response.
"""
import re
from typing import List, Dict, Any, Optional

_SYSTEM_PROMPT = """You are an expert analytics engineer generating SQL for a governed,
read-only data warehouse. Rules you MUST follow:
1. Output ONLY a single SELECT (or WITH ... SELECT) statement. No prose, no markdown fences.
2. Never use DDL or DML (no DROP/CREATE/ALTER/INSERT/UPDATE/DELETE/MERGE).
3. Always alias tables and qualify columns.
4. Include an explicit LIMIT unless the user clearly wants an aggregate with few rows.
5. Prefer explicit JOIN ... ON syntax.
6. Use the exact table/column names given in the schema context — never invent columns.
"""

_FEW_SHOT = """### Example
Schema:
- customers(customer_id, customer_name, region, status)
- orders(order_id, customer_id, order_date, order_value, cost)

Question: "Top 5 customers by total order value in Q1 2025"

SQL:
SELECT c.customer_name, SUM(o.order_value) AS total_value
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
WHERE o.order_date BETWEEN '2025-01-01' AND '2025-03-31'
GROUP BY c.customer_name
ORDER BY total_value DESC
LIMIT 5;
"""


def build_prompt(
    question: str,
    schema_context: List[Dict[str, Any]],
    semantic_hints: Optional[Dict[str, str]] = None,
    memory_examples: Optional[List[Dict[str, Any]]] = None,
) -> str:
    schema_block = "\n".join(
        f"- {t['metadata']['table']}({t['metadata'].get('columns', '')})"
        if "metadata" in t else f"- {t.get('name')}({', '.join(c['name'] for c in t.get('columns', []))})"
        for t in schema_context
    )

    semantic_block = ""
    if semantic_hints:
        semantic_block = "\nBusiness term mappings:\n" + "\n".join(
            f'- "{term}" -> {mapping}' for term, mapping in semantic_hints.items() if mapping
        )

    memory_block = ""
    if memory_examples:
        memory_block = "\nSimilar past questions (for style/pattern reference only):\n" + "\n".join(
            f'- "{m["question"]}" -> {m["sql"]}' for m in memory_examples
        )

    return f"""{_FEW_SHOT}
### Task
Schema:
{schema_block}
{semantic_block}
{memory_block}

Question: "{question}"

SQL:"""


def system_prompt() -> str:
    return _SYSTEM_PROMPT


def extract_sql(raw_response: str) -> str:
    """Strip markdown fences / prose and return the bare SQL statement."""
    text = raw_response.strip()

    fence_match = re.search(r"```(?:sql)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
    if fence_match:
        text = fence_match.group(1).strip()

    # If the model added prose before/after, isolate from the first
    # SELECT/WITH keyword onward.
    match = re.search(r"(WITH\b.*|SELECT\b.*)", text, re.DOTALL | re.IGNORECASE)
    if match:
        text = match.group(1).strip()

    return text.strip().rstrip(";").strip() + ";"
