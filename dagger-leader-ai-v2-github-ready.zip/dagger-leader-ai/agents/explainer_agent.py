class ExplainerAgent:
    def explain(self,question,sql,result=None): return {"summary":"Generated a governed read-only SQL query.","question":question,"sql":sql}
