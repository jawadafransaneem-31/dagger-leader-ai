from pathlib import Path
class WorkspaceManager:
    def __init__(self,root="workspaces"): self.root=Path(root); self.root.mkdir(exist_ok=True)
    def create(self,name):
        p=self.root/name; p.mkdir(parents=True,exist_ok=True); return str(p)
