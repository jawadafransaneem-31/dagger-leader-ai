from .base import Connector, QueryResult
class BigqueryConnector(Connector):
    name="bigquery"
    def schema(self): return [{"table":"example","columns":[{"name":"id","type":"INTEGER"},{"name":"name","type":"TEXT"}]}]
    def execute(self, sql, max_rows=100): return QueryResult(sql=sql, error="Connector adapter is configured but no live credentials are set.")
