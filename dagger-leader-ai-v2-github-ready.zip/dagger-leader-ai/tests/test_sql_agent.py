import pytest

from core.sql_generator import extract_sql, build_prompt
from governance.sql_guard import SQLGuard


def test_extract_sql_strips_markdown_fence():
    raw = "```sql\nSELECT * FROM orders LIMIT 10\n```"
    assert extract_sql(raw) == "SELECT * FROM orders LIMIT 10;"


def test_extract_sql_strips_prose():
    raw = "Sure! Here's the SQL:\nSELECT id FROM customers;"
    assert extract_sql(raw) == "SELECT id FROM customers;"


def test_build_prompt_includes_question():
    prompt = build_prompt("How many orders?", schema_context=[])
    assert "How many orders?" in prompt


def test_sql_guard_blocks_ddl():
    guard = SQLGuard()
    result = guard.validate("DROP TABLE customers;")
    assert not result.passed
    assert any("Forbidden" in r for r in result.reasons)


def test_sql_guard_blocks_dml():
    guard = SQLGuard()
    result = guard.validate("DELETE FROM orders WHERE 1=1;")
    assert not result.passed


def test_sql_guard_injects_limit():
    guard = SQLGuard(max_rows=50)
    result = guard.validate("SELECT * FROM customers")
    assert result.passed
    assert "LIMIT 50" in result.sql


def test_sql_guard_keeps_existing_limit():
    guard = SQLGuard(max_rows=50)
    result = guard.validate("SELECT * FROM customers LIMIT 5")
    assert result.passed
    assert result.sql.count("LIMIT") == 1


def test_sql_guard_flags_fan_out_risk():
    guard = SQLGuard()
    result = guard.validate(
        "SELECT c.customer_name, o.order_value FROM customers c JOIN orders o "
        "ON c.customer_id = o.customer_id LIMIT 100"
    )
    assert result.passed
    assert result.fan_out_risk
    assert any("fan-out" in w for w in result.warnings)


def test_sql_guard_rejects_empty():
    guard = SQLGuard()
    result = guard.validate("")
    assert not result.passed
