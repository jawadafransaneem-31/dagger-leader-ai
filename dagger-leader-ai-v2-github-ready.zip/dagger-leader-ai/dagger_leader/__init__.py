"""
dagger_leader

Python SDK for the Dagger Leader multi-agent data intelligence engine.

    from dagger_leader import QuantumAgent

    agent = QuantumAgent()
    result = agent.query("Show me top 5 customers by total order value in Q1 2025")

    print(result.sql)
    print(result.data)
    print(result.explanation)
    print(result.agents_used)
    print(result.healed)
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

from core.langgraph_workflow import run_pipeline
from agents.memory_agent import remember


@dataclass
class QueryResponse:
    question: str
    sql: str = ""
    data: List[Dict[str, Any]] = field(default_factory=list)
    row_count: int = 0
    explanation: str = ""
    agents_used: List[str] = field(default_factory=list)
    healed: bool = False
    heal_log: List[str] = field(default_factory=list)
    error: Optional[str] = None
    duration_ms: float = 0.0

    @property
    def success(self) -> bool:
        return self.error is None


class QuantumAgent:
    """High-level entry point wrapping the full agent pipeline."""

    def query(self, question: str, remember_result: bool = True) -> QueryResponse:
        state = run_pipeline(question)

        result = state.get("query_result") or {}
        rows = result.get("rows", [])
        columns = result.get("columns", [])
        data = [dict(zip(columns, row)) for row in rows]

        response = QueryResponse(
            question=question,
            sql=state.get("sql", ""),
            data=data,
            row_count=result.get("row_count", 0),
            explanation=state.get("explanation", ""),
            agents_used=state.get("agents_used", []),
            healed=state.get("healed", False),
            heal_log=state.get("heal_log", []),
            error=state.get("error") or None,
            duration_ms=result.get("duration_ms", 0.0),
        )

        if remember_result and response.success and response.sql:
            remember(question, response.sql, success=True)

        return response


__all__ = ["QuantumAgent", "QueryResponse"]
