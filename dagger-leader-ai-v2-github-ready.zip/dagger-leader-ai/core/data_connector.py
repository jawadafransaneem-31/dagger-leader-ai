"""
core/data_connector.py

Unified interface every data source connector implements, plus a factory
that returns the active one (config.settings.app.active_data_source).

A `MockConnector` is included and used by default so the whole pipeline
runs end-to-end without any warehouse credentials -- swap
ACTIVE_DATA_SOURCE=snowflake|bigquery in .env once you have real creds.
"""
import abc
import logging
import random
import time
from dataclasses import dataclass, field
from typing import List, Dict, Any

from config.settings import settings

logger = logging.getLogger("dagger_leader.data_connector")


@dataclass
class QueryResult:
    columns: List[str]
    rows: List[List[Any]]
    row_count: int
    duration_ms: float
    error: str = ""

    @property
    def ok(self) -> bool:
        return not self.error

    def as_dicts(self) -> List[Dict[str, Any]]:
        return [dict(zip(self.columns, row)) for row in self.rows]


class BaseConnector(abc.ABC):
    name: str = "base"

    @abc.abstractmethod
    def execute(self, sql: str) -> QueryResult:
        ...

    @abc.abstractmethod
    def list_tables(self) -> List[Dict[str, Any]]:
        """Return schema metadata: [{"name": ..., "description": ..., "columns": [...]}]"""
        ...


class MockConnector(BaseConnector):
    """In-memory demo warehouse — customers/orders — so the full agent
    pipeline (schema discovery -> SQL -> validation -> execution ->
    explanation) is runnable without any external services."""

    name = "mock"

    _SCHEMA = [
        {
            "name": "customers",
            "description": "One row per customer account.",
            "columns": [
                {"name": "customer_id", "type": "INT"},
                {"name": "customer_name", "type": "STRING"},
                {"name": "region", "type": "STRING"},
                {"name": "status", "type": "STRING"},
            ],
        },
        {
            "name": "orders",
            "description": "One row per order line, linked to customers.",
            "columns": [
                {"name": "order_id", "type": "INT"},
                {"name": "customer_id", "type": "INT"},
                {"name": "order_date", "type": "DATE"},
                {"name": "order_value", "type": "FLOAT"},
                {"name": "cost", "type": "FLOAT"},
            ],
        },
    ]

    _REGIONS = ["North America", "Europe", "APAC", "LATAM"]

    def list_tables(self) -> List[Dict[str, Any]]:
        return self._SCHEMA

    def execute(self, sql: str) -> QueryResult:
        start = time.perf_counter()
        sql_lower = sql.lower()

        # A tiny "engine" that fakes plausible results based on shape of the
        # query, purely for demo purposes.
        if "region" in sql_lower and ("sum" in sql_lower or "revenue" in sql_lower):
            columns = ["region", "total_value"]
            rows = [[r, round(random.uniform(500_000, 5_000_000), 2)] for r in self._REGIONS]
        elif "customer_name" in sql_lower:
            columns = ["customer_name", "total_value"]
            names = ["Acme Corp", "GlobalTech", "NovaSystems", "DataStream", "CloudVenture"]
            rows = sorted(
                ([n, round(random.uniform(10_000, 60_000), 2)] for n in names),
                key=lambda r: r[1],
                reverse=True,
            )
        else:
            columns = ["result"]
            rows = [["(mock connector: no matching demo dataset for this query shape)"]]

        duration_ms = (time.perf_counter() - start) * 1000
        return QueryResult(columns=columns, rows=rows, row_count=len(rows), duration_ms=duration_ms)


def get_connector() -> BaseConnector:
    source = settings.app.active_data_source.lower()

    if source == "snowflake":
        from data_sources.snowflake_connector import SnowflakeConnector
        return SnowflakeConnector()
    if source == "bigquery":
        from data_sources.bigquery_connector import BigQueryConnector
        return BigQueryConnector()

    logger.info("Using MockConnector (ACTIVE_DATA_SOURCE=%s). "
                "Set ACTIVE_DATA_SOURCE=snowflake|bigquery for a real warehouse.", source)
    return MockConnector()
