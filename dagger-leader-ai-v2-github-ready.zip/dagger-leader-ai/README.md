# Dagger Leader AI — Governed Data Agent

Dagger Leader AI is a modular, GitHub-ready data-agent foundation inspired by modern governed data-agent architectures. It separates **plan → scan → govern → build → report** and keeps execution behind an explicit governance layer.

## Features
- FastAPI gateway
- Agent orchestration: schema, semantic, SQL, validator, healer, explainer
- Read-only SQL governance with DDL/DML and dangerous-function blocking
- Automatic `LIMIT` injection
- Audit logging with basic secret redaction
- Rate limiting
- MCP-style internal tool registry
- Connector adapters for PostgreSQL, MySQL, Snowflake, BigQuery, Redshift, Databricks, DuckDB, SQLite, MSSQL, ClickHouse and Trino
- dbt build-spec/runner foundation
- Structural verification suite
- Knowledge store and isolated workspaces
- Offline deterministic mode for development/tests

## Run locally
```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows
# .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn main:app --reload
```
Open `http://127.0.0.1:8000/docs`.

## Example
```bash
curl -X POST http://127.0.0.1:8000/query \
  -H 'Content-Type: application/json' \
  -d '{"question":"How many users are there?","connector":"mock","execute":false}'
```

## Production notes
The connector classes are deliberately safe adapters and do not pretend to have live credentials. Wire each adapter to the corresponding vendor SDK/driver, add tenant authentication, secret management, persistent audit storage, sandboxing, and real MCP transport before production deployment.

## Tests
```bash
pytest -q
```
