class SchemaAgent:
    def inspect(self, connector):
        try: return connector.schema()
        except Exception as e: return [{"error":str(e)}]
