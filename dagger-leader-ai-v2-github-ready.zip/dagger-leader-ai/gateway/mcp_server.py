"""Small MCP-style tool registry. Replace adapters with an MCP SDK transport when deploying behind an MCP host."""
from typing import Callable
class ToolRegistry:
    def __init__(self): self.tools={}
    def tool(self,name,description=""):
        def deco(fn): self.tools[name]={"description":description,"handler":fn}; return fn
        return deco
    def call(self,name,**kwargs):
        if name not in self.tools: raise KeyError(name)
        return self.tools[name]["handler"](**kwargs)
registry=ToolRegistry()
@registry.tool("health","Return service health")
def health(): return {"status":"healthy"}
@registry.tool("schema","Inspect connector schema")
def schema(connector="mock"): return {"connector":connector,"tables":[]}
@registry.tool("relationships","Inspect table relationships")
def relationships(connector="mock"): return {"connector":connector,"relationships":[]}
