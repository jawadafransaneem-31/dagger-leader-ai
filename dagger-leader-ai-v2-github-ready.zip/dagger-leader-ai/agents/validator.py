class Validator:
    def validate(self,sql): return bool(sql and sql.strip().lower().startswith("select"))
