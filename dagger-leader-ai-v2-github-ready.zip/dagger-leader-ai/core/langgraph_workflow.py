from core.state import AgentState,new_state
from agents.orchestrator import Orchestrator
from governance.sql_guard import SQLGuard

def run_pipeline(question:str)->AgentState:
    state=new_state(question)
    if not question.strip(): state['error']='Question cannot be empty'; return state
    orch=Orchestrator(); connector='mock'
    schema=orch.schema.inspect(orch.__class__.__dict__.get('_dummy',None)) if False else []
    sql=orch.sql.generate(question,[{"table":"customers"}],{"schema_tables":["customers"]})
    guard=SQLGuard()
    vr=guard.validate(sql)
    state['agents_used']=['orchestrator','schema_agent','memory_agent','semantic_agent','sql_agent','validator']
    state['sql']=vr.sql; state['sql_history']=[vr.sql]; state['validation_passed']=vr.passed
    state['validation_reasons']=vr.reasons; state['validation_warnings']=vr.warnings
    if not vr.passed: state['error']=f"Query rejected by governance: {vr.reasons}"; return state
    state['explanation']=orch.explainer.explain(question,vr.sql)
    state['done']=True
    return state
class SequentialWorkflow:
    def invoke(self,state): return run_pipeline(state.get('question',''))
def build_workflow(): return SequentialWorkflow()
workflow=build_workflow()
