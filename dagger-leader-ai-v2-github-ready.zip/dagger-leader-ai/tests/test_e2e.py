"""
tests/test_e2e.py

Runs the full agent pipeline against the built-in MockConnector, so it
passes with zero external services or API keys configured (the LLM client
falls back to an offline stub in that case).

Run directly: python tests/test_e2e.py
"""
from core.langgraph_workflow import run_pipeline


def test_pipeline_runs_end_to_end():
    state = run_pipeline("Show me top 5 customers by total order value in Q1 2025")

    assert state.get("done") or state.get("error") is not None
    assert "orchestrator" in state.get("agents_used", [])
    assert "schema_agent" in state.get("agents_used", [])
    assert "sql_agent" in state.get("agents_used", [])
    assert state.get("sql", "").strip() != ""


def test_pipeline_handles_empty_question():
    state = run_pipeline("")
    assert state.get("error")


if __name__ == "__main__":
    result = run_pipeline("What was our revenue by region last quarter?")
    print("SQL:", result.get("sql"))
    print("Agents used:", result.get("agents_used"))
    print("Explanation:", result.get("explanation"))
    print("Error:", result.get("error"))
