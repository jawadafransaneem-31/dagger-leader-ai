import json, os, re, threading
from datetime import datetime, timezone
class AuditLogger:
    def __init__(self, path=None):
        self.path = path or os.getenv("AUDIT_LOG", "data/audit.jsonl")
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True); self.lock=threading.Lock()
    def _redact(self, obj):
        s=json.dumps(obj, default=str)
        s=re.sub(r'(?i)(api[_-]?key|token|password|secret)"?\s*:\s*"[^"]*"', r'\1:"[REDACTED]"', s)
        return json.loads(s)
    def write(self, event):
        event={"timestamp":datetime.now(timezone.utc).isoformat(), **self._redact(event)}
        with self.lock, open(self.path,"a",encoding="utf-8") as f: f.write(json.dumps(event)+"\n")
