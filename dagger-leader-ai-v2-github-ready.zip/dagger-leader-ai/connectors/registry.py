from .postgres import PostgresConnector
from .mysql import MysqlConnector
from .snowflake import SnowflakeConnector
from .bigquery import BigqueryConnector
from .redshift import RedshiftConnector
from .databricks import DatabricksConnector
from .duckdb import DuckdbConnector
from .sqlite import SqliteConnector
from .mssql import MssqlConnector
from .clickhouse import ClickhouseConnector
from .trino import TrinoConnector
from core.data_connector import MockConnector
CONNECTORS={"postgres":PostgresConnector,"mysql":MysqlConnector,"snowflake":SnowflakeConnector,"bigquery":BigqueryConnector,"redshift":RedshiftConnector,"databricks":DatabricksConnector,"duckdb":DuckdbConnector,"sqlite":SqliteConnector,"mssql":MssqlConnector,"clickhouse":ClickhouseConnector,"trino":TrinoConnector,"mock":MockConnector}
def get(name):
    if name not in CONNECTORS: raise ValueError(f"Unsupported connector: {name}")
    return CONNECTORS[name]()
