"""
data_sources/kafka_consumer.py

Optional real-time ingestion path. Consumes JSON events from a Kafka topic
and hands them to a callback (e.g. to refresh ChromaDB schema embeddings or
trigger anomaly checks). Not required for the core NL -> SQL pipeline.
"""
import json
import logging
import threading
from typing import Callable, Optional

from config.settings import settings

logger = logging.getLogger("dagger_leader.kafka")


class KafkaStreamConsumer:
    def __init__(self, on_message: Optional[Callable[[dict], None]] = None):
        self.on_message = on_message or (lambda msg: logger.info("Kafka message: %s", msg))
        self._consumer = None
        self._thread: Optional[threading.Thread] = None
        self._running = False

    def _build_consumer(self):
        try:
            from kafka import KafkaConsumer
        except ImportError as e:
            raise RuntimeError(
                "kafka-python is not installed. Run: pip install kafka-python"
            ) from e

        return KafkaConsumer(
            settings.kafka.topic,
            bootstrap_servers=settings.kafka.bootstrap_servers.split(","),
            group_id=settings.kafka.group_id,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            auto_offset_reset="latest",
            enable_auto_commit=True,
        )

    def start(self) -> None:
        if self._running:
            return
        self._consumer = self._build_consumer()
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        logger.info("Kafka consumer started on topic=%s", settings.kafka.topic)

    def _run(self) -> None:
        for message in self._consumer:
            if not self._running:
                break
            try:
                self.on_message(message.value)
            except Exception as e:
                logger.error("Error handling Kafka message: %s", e)

    def stop(self) -> None:
        self._running = False
        if self._consumer:
            self._consumer.close()
        logger.info("Kafka consumer stopped.")
