"""
core/state.py

Shared state object passed between every node of the LangGraph pipeline.
Kept as a plain TypedDict (rather than agent-specific objects) so LangGraph
can merge partial updates from each node automatically.
"""
from typing import TypedDict, List, Dict, Any, Optional


class AgentState(TypedDict, total=False):
    # input
    question: str

    # orchestrator
    sub_tasks: List[str]
    agents_used: List[str]

    # schema agent
    schema_context: List[Dict[str, Any]]

    # memory agent
    memory_examples: List[Dict[str, Any]]

    # semantic agent
    semantic_hints: Dict[str, str]

    # sql agent
    sql: str
    sql_history: List[str]

    # validator
    validation_passed: bool
    validation_reasons: List[str]
    validation_warnings: List[str]

    # execution
    query_result: Optional[Dict[str, Any]]
    execution_error: str

    # healer
    heal_attempts: int
    healed: bool
    heal_log: List[str]

    # explainer
    explanation: str

    # misc
    error: str
    done: bool


def new_state(question: str) -> AgentState:
    return AgentState(
        question=question,
        sub_tasks=[],
        agents_used=[],
        schema_context=[],
        memory_examples=[],
        semantic_hints={},
        sql="",
        sql_history=[],
        validation_passed=False,
        validation_reasons=[],
        validation_warnings=[],
        query_result=None,
        execution_error="",
        heal_attempts=0,
        healed=False,
        heal_log=[],
        explanation="",
        error="",
        done=False,
    )
