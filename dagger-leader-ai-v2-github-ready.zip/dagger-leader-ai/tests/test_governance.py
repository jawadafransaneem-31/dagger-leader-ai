from governance.sql_guard import SQLGuard
def test_blocks_mutation(): assert not SQLGuard().inspect("DROP TABLE users")["allowed"]
def test_adds_limit(): assert "LIMIT 10" in SQLGuard().inspect("SELECT * FROM users",10)["sql"]
