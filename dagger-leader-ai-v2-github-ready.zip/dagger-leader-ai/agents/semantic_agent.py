class SemanticAgent:
    def analyze(self, question, schema):
        return {"question_type":"analytical","entities":[],"metrics":[],"time_dimension":None,"schema_tables":[x.get("table") for x in schema if isinstance(x,dict) and x.get("table")]}
