import re
class SQLAgent:
    def generate(self, question, schema, intent):
        # Deterministic baseline; replace with LLM generation in core/llm_client.py.
        table=(intent.get("schema_tables") or ["example"])[0]
        q=question.lower()
        if "count" in q or "how many" in q: return f"SELECT COUNT(*) AS count FROM {table}"
        return f"SELECT * FROM {table}"
