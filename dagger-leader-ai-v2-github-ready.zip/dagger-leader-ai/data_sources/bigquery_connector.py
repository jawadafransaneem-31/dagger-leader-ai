"""
data_sources/bigquery_connector.py

Real BigQuery connector. Requires `google-cloud-bigquery` and
GOOGLE_APPLICATION_CREDENTIALS pointing at a service-account JSON key.
"""
import logging
import time
from typing import List, Dict, Any

from config.settings import settings
from core.data_connector import BaseConnector, QueryResult

logger = logging.getLogger("dagger_leader.bigquery")


class BigQueryConnector(BaseConnector):
    name = "bigquery"

    def __init__(self):
        self._client = None
        self._connect()

    def _connect(self):
        try:
            from google.cloud import bigquery
        except ImportError as e:
            raise RuntimeError(
                "google-cloud-bigquery is not installed. "
                "Run: pip install google-cloud-bigquery"
            ) from e

        if not settings.bigquery.project_id:
            raise RuntimeError("Missing BQ_PROJECT_ID env var.")

        self._client = bigquery.Client(project=settings.bigquery.project_id)
        logger.info("Connected to BigQuery project=%s", settings.bigquery.project_id)

    def execute(self, sql: str) -> QueryResult:
        from google.cloud import bigquery

        start = time.perf_counter()
        try:
            job_config = bigquery.QueryJobConfig(
                dry_run=False,
                use_query_cache=True,
            )
            job = self._client.query(sql, job_config=job_config, timeout=settings.governance.query_timeout_seconds)
            result = job.result()
            columns = [field.name for field in result.schema]
            rows = [list(row.values()) for row in result]
            duration_ms = (time.perf_counter() - start) * 1000
            return QueryResult(columns=columns, rows=rows, row_count=len(rows), duration_ms=duration_ms)
        except Exception as e:
            duration_ms = (time.perf_counter() - start) * 1000
            logger.error("BigQuery query failed: %s", e)
            return QueryResult(columns=[], rows=[], row_count=0, duration_ms=duration_ms, error=str(e))

    def list_tables(self) -> List[Dict[str, Any]]:
        dataset_ref = self._client.dataset(settings.bigquery.dataset)
        tables = []
        for table_item in self._client.list_tables(dataset_ref):
            table = self._client.get_table(table_item.reference)
            columns = [{"name": f.name, "type": f.field_type} for f in table.schema]
            tables.append({
                "name": table.table_id,
                "description": table.description or "",
                "columns": columns,
            })
        return tables
